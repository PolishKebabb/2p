const wynik = document.querySelector("#wynik");
function sprawdz(form){
    let nazwa = document.getElementById('nazwa').value;
    let email = document.getElementById('email').value;
    let haslo1 = document.getElementById('haslo1').value;
    let haslo2 = document.getElementById('haslo2').value;

    if (nazwa == '') {
        alert('Pole "nazwa" musi być wypełnione');
        form.nazwa.focus();
        return false;
    }
    if (email == '' || !email.endsWith("@zspglogow.pl")){
        alert('Pole email nie moze byc puste i musi miec domenę @zspglogow.pl');
        form.email.focus();
        return false;
    }

    const hasloZnaki = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
    if (!hasloZnaki.test(haslo1)) {
        alert("Hasło musi zawierać co najmniej 8 znaków, w tym małą i dużą literę, cyfrę oraz znak specjalny");
        return false;
    }

    if (haslo1 == '' || haslo2 == ''){
        alert("Hasła nie moga byc puste");
        form.haslo1.focus()
        return false;
    }

    if (haslo1 !== haslo2) {
        alert("Hasła nie sa identyczne");
        form.haslo1.focus()
        return false;
    }

    alert("Dane prawidłowe. Wysłano formularz.");
    document.write("Nazwa: " + nazwa + " Email: " + email + " Haslo: " + haslo1);
    return true;
}